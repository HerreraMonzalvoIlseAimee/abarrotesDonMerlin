from customtkinter import *
from PIL import Image, ImageTk
from ventanaUsuario import ventanaRegistrar

def ocultarContra():
    if entryPass1U.cget("show") == "":
        entryPass1U.configure(show="*")
        ocultarA.configure(text="👁‍")
    else:
        entryPass1U.configure(show="")
        ocultarA.configure(text="🔒")

def ocultarContraU():
    if entryPassU.cget("show") == "":
        entryPassU.configure(show="*")
        ocultarU.configure(text="👁‍")
    else:
        entryPassU.configure(show="")
        ocultarU.configure(text="🔒")
      
def mostrarPantalla(pantalla): #Ver que pantalla mostrar
    pantallaLogin.pack_forget() #El .pack oculta las demás pantallas de la vista
    pantallaAdmin.pack_forget()
    pantalla.pack(fill="both", expand=True) #Muetra el nuevo frame
    

def loginAdmin():
    datosAdmin= []
    datosAdmin.append('Admin_790')
    datosAdmin.append('1450Contra')
    usuAdmin= entryAdmin.get() #Guarda lo que ingresas en el campo
    #print("Usuario:", usuAdmin)
    Contra = entryPass1U.get()
    #print("Contraseña:", Contra)
    if datosAdmin[0] == usuAdmin and datosAdmin[1] == Contra:
        mostrarPantalla(pantallaAdmin) #Mostrar ahora la pantalla admin
    else:
        print("Usuario o contraseña incorrecto")

def mensajeRegist():
    CTkLabel(frameUser, text= "Usuario Registrado", text_color="white", bg_color="#3159B6",font=("Bahnschrift",10)).place(x=90,y=177)

def loginUsuario():
    print("h")
    

raiz=CTk()
raiz.geometry("1280x720") ##tamaño
raiz.title("**ABARROTES DON MERLIN**") ##Titulo
raiz.resizable(True,True) ##redimensionar
raiz.configure(bg= "black")

raiz.iconbitmap("frog.ico") ##icono

pantallaLogin = CTkFrame(master=raiz, fg_color="black")
pantallaLogin.pack(fill="both", expand=True) #Empacar todo todo lo de la pantalla de logeo

imagen_pil = Image.open("Ranaa.png")
imagen_ctk = CTkImage(light_image=imagen_pil, size=(350, 300)) #Tamaño
label_imagen = CTkLabel(master=raiz,bg_color="black", image=imagen_ctk, text="") #Texto vacío para que solo se vea la imagen
label_imagen.place(x=760, y=400)

CTkLabel(raiz, text= "ABARROTES\nDON\nMERLIN", text_color="orange", bg_color="black",font=("Old English Text MT", 90)).place(x=610,y=40)
CTkLabel(raiz, text= "BIENVENIDO  :)", text_color="white", bg_color="black",font=("Papyrus",34)).place(x=120,y=10)


#--------------------Frame Usuarios--------------------
frameUser = CTkFrame(master=pantallaLogin, width=450, height=240, fg_color="grey")
frameUser.place(x=120, y=80) #Ajusta la posicion en pantalla

frameUser.configure(border_width=10)

CTkLabel(frameUser, text= "CLIENTE", text_color="purple", bg_color="grey",font=("Bahnschrift",45)).place(x=135,y=15)

botonIngU = CTkButton(frameUser,text="Ingresar",fg_color="#3159B6")
botonIngU.place(relx=0.7,rely=0.8,anchor= "center")

#Ventana para registrarse
botonRegistU = CTkButton(frameUser, text="Registrarse",fg_color="#3159B6", command=lambda:ventanaRegistrar(raiz, mensajeRegist))
botonRegistU.place(relx=0.3,rely=0.8,anchor= "center")

CTkLabel(frameUser, text= "Usuario:", text_color="white", bg_color="grey",font=("Bahnschrift",25)).place(relx=0.15,rely=0.334)
entryUsrU = CTkEntry(frameUser, placeholder_text="Nombre de Usuario")
entryUsrU.place(relx=0.54,rely=0.35)
CTkLabel(frameUser, text= "Contraseña:", text_color="white", bg_color="grey",font=("Bahnschrift",25)).place(relx=0.15,rely=0.53)
entryPassU = CTkEntry(frameUser, placeholder_text="Contraseña", show="*")
entryPassU.place(relx=0.54,rely=0.55)

ocultarU = CTkButton(frameUser, text="👁‍",fg_color="#305CA8",font=("Bahnschrift",15), command=ocultarContraU, width=30)
ocultarU.place(relx=0.86,rely=0.55)

#--------------------Frame Admin--------------------
frameAdmin = CTkFrame(master=pantallaLogin , width=450, height=240, fg_color="grey")
frameAdmin.place(x=120, y=370) #Ajusta la posicion en pantalla

frameAdmin.configure(border_width=10)

CTkLabel(frameAdmin, text= "ADMIN", text_color="orange", bg_color="grey",font=("Bahnschrift",45)).place(x=145,y=15)

botonIngU = CTkButton(frameAdmin,text="Ingresar",fg_color="#3159B6", command=loginAdmin)
botonIngU.place(relx=0.7,rely=0.8,anchor= "center")

CTkLabel(frameAdmin, text= "Usuario:", text_color="white", bg_color="grey",font=("Bahnschrift",25)).place(relx=0.15,rely=0.334)
entryAdmin = CTkEntry(frameAdmin, placeholder_text="Nombre de usuario")
entryAdmin.place(relx=0.54,rely=0.35)
CTkLabel(frameAdmin, text= "Contraseña:", text_color="white", bg_color="grey",font=("Bahnschrift",25)).place(relx=0.15,rely=0.53)

entryPass1U = CTkEntry(frameAdmin, placeholder_text="Contraseña", show="*") #Que se vea solo ****
entryPass1U.place(relx=0.54,rely=0.55)

ocultarA = CTkButton(frameAdmin, text="👁‍",fg_color="#305CA8",font=("Bahnschrift",15), command=ocultarContra, width=30)
ocultarA.place(relx=0.86,rely=0.55)



#-------------------- Pantalla admin --------------------
pantallaAdmin = CTkFrame(master=raiz, fg_color="black")
    
raiz.mainloop()
