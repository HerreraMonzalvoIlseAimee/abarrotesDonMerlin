from customtkinter import *
def ventanaRegistrar(ventanaPadre):
    # Crea la ventana secundaria
    ventanaUsuario = CTkToplevel()
    ventanaUsuario.geometry("1100x700")
    ventanaUsuario.configure(bg_color ="black")
    ventanaUsuario.title("ABARROTES DON MERLíN")

    
    #Comportamiento al cerrar:
    #ventanaUsuario.protocol("WM_DELETE_WINDOW", lambda: [ventanaUsuario.destroy(),ventanaPadre.deiconify()])
    #return ventanaUsuario
