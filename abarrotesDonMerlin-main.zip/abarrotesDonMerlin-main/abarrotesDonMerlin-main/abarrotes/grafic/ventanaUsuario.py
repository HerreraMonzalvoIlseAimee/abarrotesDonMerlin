from customtkinter import *

def ventanaRegistrar(ventanaPadre, callback):
    # Crea la ventana secundaria
    ventanaReg = CTkToplevel(ventanaPadre) #Crea ventana nueva
    ventanaReg.focus_force() # Se posiciona adelante de la otra ventana
    ventanaReg.lift() # La eleva por encima de otras ventanas
    ventanaReg.grab_set() # Bloquea la ventana principal hasta que cierres esta
    ventanaReg.title("Registro de Usuario")
    ventanaReg.geometry("400x400")
    ventanaReg.configure(fg_color ="black")

    CTkLabel(ventanaReg, text="Registro de Usuario", font=("Arial", 20)).pack(pady=20)
    entryUsuario = CTkEntry(ventanaReg, placeholder_text= "Nombre de Usuario")
    entryUsuario.pack(pady=4)
    entryContra = CTkEntry(ventanaReg, placeholder_text= "Contraseña", show="*")
    entryContra.pack(pady=10)

    def registrarUsuario(entryUsuario, entryContra, ventanaReg):
        usuario = entryUsuario.get()
        contra = entryContra.get()
        usuarios={
            "Prueba": {
                "Contraseña": "123"
                }
            }
        if usuario in usuarios:
            CTkLabel(ventanaReg, text="Usuario ya existente", font=("Arial", 14)).place(x=130,y=145)
            print("Usuario ya existente")
        else:
            usuarios[usuario] = {
                "Contraseña" : contra
                }
            print("Usuario registrado")
            print(usuarios)
            ventanaReg.destroy() #Cerramos la ventana
            callback() #Mostar el mensaje en la pantalla principal
        
    CTkButton(ventanaReg, text="Registrarse", command=lambda: registrarUsuario(entryUsuario, entryContra, ventanaReg)).pack(pady=28)

