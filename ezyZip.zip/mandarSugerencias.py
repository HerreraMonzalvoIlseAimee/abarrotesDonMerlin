from customtkinter import *
from PIL import Image, ImageTk
def sugerencias(ventanaPadre):
    def texto(entrada):
        contenido = entrada.get("1.0", "end") 
        archivo=openpyxl.load_workbook("sugerencias.xlsx")
        hoja = archivo["sugerencias"]
        donde=int(hoja["E1"].value)
        donde+=1
        hoja["E1"]=str(donde)
        celda="A"+str(donde)  
        hoja[celda]=contenido
        entrada.delete("1.0", "end")
        archivo.save("sugerencias.xlsx")

    import openpyxl
    ventanaUsr = CTkToplevel(ventanaPadre)
    ventanaUsr.geometry("1280x720") ##tamaño
    ventanaUsr.title("**SUGERENCIAS: ABARROTES DON MERLIN**") ##Titulo
    ventanaUsr.resizable(True,True) ##redimensionar
    ventanaUsr.configure(fg_color= "#634373")
    ventanaUsr.grid_columnconfigure((1,2,3),weight=1)
    ventanaUsr.grid_rowconfigure((1,2),weight=1)

    entrada=CTkTextbox(ventanaUsr,
                       width=500,
                       height=400,
                       font=("Chiller",35),
                       fg_color="#9365a9",
                       text_color="white",
                       corner_radius=20)
    entrada.grid(row=1, column=2)
    boton = CTkButton(ventanaUsr,
                      width=100,
                      height=60,
                      font=("Old English Text MT",25),
                      text="mandar",
                      fg_color="#302137",
                      text_color="white",
                      command=lambda:[texto(entrada)])
    boton.grid(row=2,column=2,sticky="n")
    imagen_pil = Image.open("carta.png")
    imagen_ctk = CTkImage(light_image=imagen_pil, size=(200, 140)) #Tamaño
    label_imagen = CTkLabel(master=ventanaUsr,bg_color="transparent", image=imagen_ctk, text="") #Texto vacío para que solo se vea la imagen
    label_imagen.place(relx=0.4389,rely=0.855)
    ventanaUsr.protocol("WM_DELETE_WINDOW", lambda:[ventanaUsr.destroy(),ventanaPadre.deiconify()])
